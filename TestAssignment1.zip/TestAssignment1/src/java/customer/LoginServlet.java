package customer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 *
 * @author Alvie Zhang
 */
@WebServlet(urlPatterns = {"/LoginServlet"}, initParams =
{
   @WebInitParam(name = "dbTable", value = "testUnrestricted.Clients")
   ,@WebInitParam(name="dbFirstname",value="Firstname")
   ,@WebInitParam(name="dbLastname",value="Lastname")
   , @WebInitParam(name = "dbEmail", value = "Email")
   , @WebInitParam(name = "dbPassword", value = "password")
   ,@WebInitParam(name="dbClientname",value="Client_ID")
   
})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   private Logger logger;
    @Resource (mappedName="jdbc/assignment1")
   private DataSource dataSource;
    Connection con=null;
    PreparedStatement psd=null;
    ResultSet rs=null;
    String sqlCommand="";
    private final char QUOTE = '"';
    private String email;
    private Login login=new Login();
    private static String firstname;
     static  String clientname;
    private String password;
    static String customerID;
    private static String id;
    public LoginServlet()
    {
        logger = Logger.getLogger(getClass().getName());
    }
   @Override
   public void init()
   {
      // obtain servlet configuration values from annotation or web.xml
      ServletConfig config = getServletConfig();
      String dbTable = config.getInitParameter("dbTable");
      String dbFirstname=config.getInitParameter("dbFirstname");
      String dbLastname=config.getInitParameter("dbLastname");
      String dbEmail = config.getInitParameter("dbEmail");
      String dbPassword = config.getInitParameter("dbPassword");
      String dbClientname=config.getInitParameter("dbClientname");
     
      /*sqlCommand = "SELECT " + dbEmail + " AS Username," + dbPassword
         + " AS Password FROM" +dbTable+" WHERE " + dbEmail+" LIKE ? AND "+dbPassword+" Like ?";*/
      sqlCommand="SELECT "+dbFirstname+" AS firstname, "+dbLastname+" AS lastname, "+dbClientname+" AS clientID "+"FROM "+dbTable+" WHERE "
              + dbEmail+" = ? AND "+dbPassword+" = ? ";
        
   }
  
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // check whether redirect to PetEntityServlet to handle request
      String inputEmail = request.getParameter("email");
      String inputPassword = request.getParameter("password");
     
      // obtain the pet species request parameter
      
      if ((inputEmail == null || inputEmail.length() == 0) && (inputPassword == null || inputPassword.length() == 0))
         inputEmail = "%";
         //inputPassword = "%";
      // query database
      Connection conn = null;
      PreparedStatement prepStmt = null;
      ResultSet resultSet = null;
      if (sqlCommand != null && dataSource != null)
      {
         try
         {
            conn = dataSource.getConnection();
            prepStmt = conn.prepareStatement(sqlCommand);
            prepStmt.setString(1, inputEmail);
            prepStmt.setString(2, inputPassword);
            resultSet = prepStmt.executeQuery();
           
            logger.info("Successfully executed query for species "
               + inputEmail);
         }
         catch (SQLException e)
         {
            logger.severe("Unable to execute query for species "
               + inputEmail + ": " + e);
            response.setContentType("text/html;charset=UTF-8");
          
         }
      }
      // set response headers before returning any message content
      response.setContentType("text/html;charset=UTF-8");
      try (PrintWriter out = response.getWriter())
      {
         out.println("<!DOCTYPE html>");
         out.println("<html>");
         out.println("<head>");
         out.println("<title>Login Servlet Response</title>");
         out.println("</head>");
         out.println("<body>");
         out.println("<h1>Welcome " + filter(inputEmail)
            + "</h1>");
         if (resultSet != null)
         {
            out.println("<TABLE cellspacing=1 border=5>");
            out.println("<TR><TD><B>ClientID</B></TD>"
                    + "<TD><B>Fullname</B>"
               + "<TD><B>Username</B></TD></TR>");
           
            try
            {
               while (resultSet.next())
               {
                  String username = inputEmail;
                  firstname=resultSet.getString("firstname");
                  String lastname=resultSet.getString("lastname");
                   id=resultSet.getString("clientID");
                 login.setId(id);
                 customerID=id;
                //  String password = resultSet.getString("Password");
                  login.setClientFirstname(firstname);
                  clientname=firstname;
                  
                  login.setClientLastname(lastname);
                  out.println("<TR><TD>" + filter(id)+ "</TD><TD>"
                          + "<TD>" + filter(firstname) +" "+filter(lastname)+ "</TD>"
                     + filter(username) + "</TD></TR>");
               }
            }
            catch (SQLException e)
            {
               logger.severe("Exception in result set for species "
                  + inputEmail + ": " + e);
               
            }
            out.println("</TABLE>");
         }
         try
         {
            if (prepStmt != null)
               prepStmt.close();
            if (conn != null)
               conn.close(); // release conn back to pool
         }
         catch (SQLException e)
         {  // ignore
         }
         
        /* out.println("<P><A href=" + QUOTE
            + response.encodeRedirectURL("product.jsp") + QUOTE +">"
            + "Return to login Page</A></P>");
         out.println("</body>");
         out.println("</html>");*/
          login.setEmail(inputEmail);
          login.setPassword(inputPassword);
          request.setAttribute("Login", login);
          RequestDispatcher dispatcher = getServletContext().
                  getRequestDispatcher("/product.jsp");
          dispatcher.forward(request, response);

      }
         
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
     public static String filter(String text)
   {
      StringBuilder buffer = new StringBuilder();
      for (int i = 0; i < text.length(); i++)
      {
         char c = text.charAt(i);
         if (c == '<')
            buffer.append("&lt;");
         else if (c == '>')
            buffer.append("&gt;");
         else if (c == '\"')
            buffer.append("&quot;");
         else if (c == '\'')
            buffer.append("&#39;");
         else if (c == '&')
            buffer.append("&amp;");
         else
            buffer.append(c);
      }
      return buffer.toString();
   }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
