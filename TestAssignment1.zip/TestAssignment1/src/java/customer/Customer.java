/**
 * Customer JavaBean that represents a customer
 *
 * @see CustomerServlet.java
 */
package customer;

import java.io.Serializable;
import java.util.Random;

public class Customer implements Serializable
{
   public static enum GENDER
   {
      MALE, FEMALE
   };
   static String test;
   private String firstName;
   private String lastName;
   private int yearOfBirth;
   private GENDER gender;
   private String email;
   private int minYear; // min bound for year of birth
   private int maxYear; // max bound for year of birth
   private String password;
   private String id;
   /**
    * Creates a new instance of Customer
    */
   public Customer()
   {
      firstName = null;
      lastName = null;
      yearOfBirth = 1980;
      gender = GENDER.FEMALE;
      email=null;
      id=null;
   }

   public String getFirstName()
   {
      return firstName;
   }

   public void setFirstName(String firstName)
   {
      this.firstName = firstName;
   }

   public String getLastName()
   {
      return lastName;
   }

   public void setLastName(String lastName)
   {
      this.lastName = lastName;
   }

   public int getYearOfBirth()
   {
      return yearOfBirth;
   }

   public void setYearOfBirth(int yearOfBirth)
   {
      this.yearOfBirth = yearOfBirth;
   }

   public GENDER getGender()
   {
      return gender;
   }

   public void setGender(GENDER gender)
   {
      this.gender = gender;
   }

   public int getMinYear()
   {
      return minYear;
   }

   public void setMinYear(int minYear)
   {
      this.minYear = minYear;
   }

   public int getMaxYear()
   {
      return maxYear;
   }

   public void setMaxYear(int maxYear)
   {
      this.maxYear = maxYear;
   }
   public String getEmail()
   {
       return email;
   }
   public void setEmail(String mail)
   {
       this.email=mail;
   }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
   
   
}
