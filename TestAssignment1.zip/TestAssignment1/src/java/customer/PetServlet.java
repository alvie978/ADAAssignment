/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customer;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 *
 * @author Alvie Zhang
 */
@WebServlet(name = "PetServlet", urlPatterns = {"/submitPet"}
, initParams ={
 @WebInitParam(name="minYear",value="1900"),
 @WebInitParam(name="maxYear",value="2020"),
 
 @WebInitParam(name="dbTable",value="HousePet"),
  @WebInitParam(name="dbTable2",value="Clients"),
 @WebInitParam(name="dbPetID",value="PetID"),
 @WebInitParam(name="dbPetname",value="Petname"),
 @WebInitParam(name="dbGender",value="gender"),
 @WebInitParam(name="dbOwner",value="Ownername"),
 @WebInitParam(name="dbBirthyear",value="birthYear"),
 @WebInitParam(name="dbClientID",value="Client_ID"), 
})
public class PetServlet extends HttpServlet {
 @Resource (mappedName="jdbc/assignment1")
   private DataSource dataSource;
   private  Logger logger; 
   private String sqlCommand1;
   private String sqlCommand2;
   private int minYear, maxYear;
    Connection con=null;
   PreparedStatement psd=null;
   ResultSet rs=null;
   private Pet pets=new Pet();
   public PetServlet()
   {
        logger = Logger.getLogger(this.getClass().getName());
   }
    @Override
   public void init(){
       ServletConfig config = getServletConfig();
        try
      {
         minYear = Integer.parseInt(config.getInitParameter("minyear"));
         maxYear = Integer.parseInt(config.getInitParameter("maxyear"));
         String table1=config.getInitParameter("dbTable");
         String table2=config.getInitParameter("dbTable2");
         sqlCommand1="SELECT * FROM "+table1+";";
         sqlCommand2="SELECT * FROM "+table2+";";
      }
      catch (NumberFormatException e)
      {
         logger.warning("Invalid min/max years specified in web.xml");
      }
       
   }
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String currentUser=LoginServlet.clientname;
        String currentUserID=LoginServlet.customerID;
        String petname=request.getParameter("petName");
        String birthYear=request.getParameter("birthYear");
        String gender=request.getParameter("gender");
        String category=request.getParameter("cate");
        int year;
      try
      {
         year = Integer.parseInt(birthYear);
      }
      catch (NumberFormatException e)
      {
         year = minYear - 1;
      }
      // perform some basic validation on parameters
      boolean validated = true;
       if (petname == null || petname.length() < 0 ||
         petname.length() > 20)
         validated = false;
      
    
      if (validated)
      {      
          pets.setPetName(petname);
          pets.setOwnerName(currentUser);
          pets.setOwnerID(currentUserID);
          pets.setCategory(category);
         if (gender.equalsIgnoreCase("male"))
            pets.setGender(Pet.GENDER.MALE.toString());
         else if (gender.equalsIgnoreCase("female"))
            pets.setGender(Pet.GENDER.FEMALE.toString());
        newPet(pets);
      }
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet PetServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Congras, " + LoginServlet.clientname + " you registered your pet successfully </h1>");
            
            out.println("<a href='Search.jsp'>You can perform search function here</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }
   
    
    private int newPet(Pet pet)
    {
         int result = 0;
         Random ran=new Random();
        int id=ran.nextInt();
          if(id<0)
          {
              id=id*(-1);
          }
          else
          {
              id=id;
          }
          pet.setPetID(id);
     try {
         con=dataSource.getConnection();
         sqlCommand1="INSERT INTO testUnrestricted.HousePet VALUES (?,?,?,?,?,?)";
        
         psd=con.prepareStatement(sqlCommand1);
         
         psd.setString(1,String.valueOf(pet.getPetID()));
         psd.setString(2,pet.getPetName() );
         psd.setString(3, pet.getGender());
         psd.setString(4, pet.getOwnerName());
         psd.setString(5, pet.getOwnerID());
         psd.setString(6, pet.getCategory());
          result = psd.executeUpdate();
           sqlCommand2="Update testUnrestricted.Clients SET PetID = "+pet.getPetID()+" "
                   + "WHERE Client_ID = "+pet.getOwnerID();
          psd=con.prepareStatement(sqlCommand2);
          result=psd.executeUpdate();
          psd.close();
         logger.info("Succefully added the pet info to the database");
         logger.info("Succefully executed the sqlcommand2");


     } catch (SQLException ex) {
        logger.severe(ex.toString());
     }
          
         return result;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
