/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customer;


/**
 *
 * @author Alvie Zhang
 */
public class Pet {
   
    public static enum GENDER
   {
      MALE, FEMALE
   };
    private int petID;
    private String petName;
    private String ownerName;
    private String category;
    private String ownerID;
    private String gender;
    
    public Pet()
    {
        petID=-1;
        petName="";
        ownerName="";
       category="";
        ownerID="";
    }

    public int getPetID() {
        return petID;
    }

    public void setPetID(int petID) {
        this.petID = petID;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerID() {
        return ownerID;
    }

    public void setOwnerID(String ownerID) {
        this.ownerID = ownerID;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    
    

    
   
    
    
    
    
}
