/**
 * A servlet that handles an HTTP request with customer information
 * and performed basic validation on the information, before
 * preparing a Customer bean which it passes along to the
 * Confirmation.jsp to present in the HTTP response.
 *
 * @author Andrew Ensor
 */
package customer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

@WebServlet(name = "CustomerServlet", urlPatterns =
{
   "/lookup"
}, initParams =
{
   @WebInitParam(name="minyear", value="1900"),
   @WebInitParam(name="maxyear", value="2020"),
   @WebInitParam(name="dbTable",value="Clients"),
@WebInitParam(name="dbFirstnameAtt",value="Firstname"),
@WebInitParam(name="dbLastnameAtt",value="Lastname"),
@WebInitParam(name="dbEmailAtt",value="Email"),
@WebInitParam(name="dbPasswordAtt",value="password"),
@WebInitParam(name="dbBirthyearAtt",value="birthYear")
})
public class CustomerServlet extends HttpServlet
{

   private Logger logger;
   private int minYear, maxYear;
  // private CustomerDatabase cd;
   private String sqlCommand;
   @Resource (mappedName="jdbc/assignment1")
   private DataSource dataSource;
   private Random ran=new Random();
   Connection con=null;
   PreparedStatement psd=null;
   ResultSet rs=null;
   private String username="student";
   private String password="fpn871";
  
   public CustomerServlet()
   {  // obtain a logger for warnings
      logger = Logger.getLogger(this.getClass().getName());
   }

   @Override
   public void init()
   {
      // obtain servlet configuration values from annotation or web.xml
       ServletConfig config = getServletConfig();
       String tableName = config.getInitParameter("dbTable");
       String firstNameAtt = config.getInitParameter("dbFirstnameAtt");
       String lastNameAtt = config.getInitParameter("dbLastnameAtt");
       String emailAtt = config.getInitParameter("dbEmailAtt");
       String passwordAtt = config.getInitParameter("dbPasswordAtt");
       String birthyearAtt = config.getInitParameter("dbBirthyearAtt"); 
       
      try
      {
         minYear = Integer.parseInt(config.getInitParameter("minyear"));
         maxYear = Integer.parseInt(config.getInitParameter("maxyear"));
         sqlCommand="SELECT * FROM "+tableName+";";
      }
      catch (NumberFormatException e)
      {
         logger.warning("Invalid min/max years specified in web.xml");
      }
   }

   protected void processRequest(HttpServletRequest request,
      HttpServletResponse response)
      throws ServletException, IOException
   {
      String firstName = request.getParameter("firstname");
      String lastName = request.getParameter("lastname");
      String yearOfBirth = request.getParameter("yearofbirth");
      String gender = request.getParameter("gender");
      String email=request.getParameter("email");
      String password = request.getParameter("password");
      
      int year;
      try
      {
         year = Integer.parseInt(yearOfBirth);
      }
      catch (NumberFormatException e)
      {
         year = minYear - 1;
      }
      // perform some basic validation on parameters
      boolean validated = true;
      if (firstName == null || firstName.length() < 2 ||
         firstName.length() > 20)
         validated = false;
      if (lastName == null || lastName.length() < 2 ||
         firstName.length() > 20)
         validated = false;
      if (year < minYear || year > maxYear)
         validated = false;
      if (validated)
      {  // put customer information into a request bean
         Customer customer = new Customer();
         customer.setFirstName(firstName);
         customer.setLastName(lastName);
         customer.setMinYear(minYear);
         customer.setMaxYear(maxYear);
         customer.setYearOfBirth(year);
         customer.setEmail(email);
         customer.setPassword(password);
        
         if (gender.equalsIgnoreCase("male"))
            customer.setGender(Customer.GENDER.MALE);
         else if (gender.equalsIgnoreCase("female"))
            customer.setGender(Customer.GENDER.FEMALE);
         request.setAttribute("Customer", customer);
        
         RequestDispatcher dispatcher = getServletContext().
            getRequestDispatcher("/index.jsp");
         dispatcher.forward(request, response);
         newCustomers(customer);
       
        
      }
      else
      {  // display the Customer details form
         // note should give user info why parameters not validated
         RequestDispatcher dispatcher = getServletContext().
            getRequestDispatcher("/Error.jsp");
         dispatcher.forward(request, response);
      }
   }
   private int newCustomers(Customer customer)
   {
       int result = 0;
       String command = "";
       String driver = "com.mysql.jdbc.Driver";
       String url = "jdbc:mysql://raptor2.aut.ac.nz:3306/Other databases/testUnrestricted";
       /* try {
           Class.forName(driver);
           
           } catch (ClassNotFoundException ex) {
           Logger.getLogger(CustomerServlet.class.getName()).log(Level.SEVERE, null, ex);
           }*/
     try {
           con = dataSource.getConnection();
           sqlCommand = "Insert INTO testUnrestricted.Clients VALUES (?,?,?,?,?,?,?);";
           psd = con.prepareStatement(sqlCommand);
           int id=ran.nextInt();
           if(id<0)
           {
               id=id*(-1);
           }
           else
           {
               id=id;
           }
           psd.setString(1, String.valueOf(id));
           psd.setString(2, customer.getFirstName());
           psd.setString(3, customer.getLastName());
           psd.setString(4, customer.getEmail());
           psd.setString(5, customer.getPassword());
           psd.setString(6, String.valueOf(customer.getYearOfBirth()));
           psd.setString(7, null);
           result = psd.executeUpdate();
           logger.info("Succefully added to database");
           psd.close();

       } catch (SQLException ex) {
           logger.severe(ex.getMessage());
       }
       return result;
       
   }

   // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
   /**
    * Handles the HTTP <code>GET</code> method.
    *
    * @param request servlet request
    * @param response servlet response
    * @throws ServletException if a servlet-specific error occurs
    * @throws IOException if an I/O error occurs
    */
   @Override
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
   {
      processRequest(request, response);
   }

   /**
    * Handles the HTTP <code>POST</code> method.
    *
    * @param request servlet request
    * @param response servlet response
    * @throws ServletException if a servlet-specific error occurs
    * @throws IOException if an I/O error occurs
    */
   @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
   {
      processRequest(request, response);
   }

   /**
    * Returns a short description of the servlet.
    *
    * @return a String containing servlet description
    */
   @Override
   public String getServletInfo()
   {
      return "Short description";
   }// </editor-fold>

}
