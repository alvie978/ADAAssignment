/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customer;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 *
 * @author Alvie Zhang
 */
@WebServlet(name = "SearchServlet", urlPatterns = {"/searchPet"},
initParams={
       @WebInitParam(name="dbTable1",value="testUnrestricted.HousePet"),
       @WebInitParam(name="dbTable2",value="testUnrestricted.Clients"),
       @WebInitParam(name="dbfirstname",value="Firstname"),
       @WebInitParam(name="dblastname",value="Lastname"),
       @WebInitParam(name="dbEmail",value="Email"),
       @WebInitParam(name="dbBirthyear",value="birthYear"),
       @WebInitParam(name="dbPetID",value="PetID"),
       @WebInitParam(name="dbPetname",value="Petname"),
       @WebInitParam(name="dbPetGender",value="gender"),
       @WebInitParam(name="dbOwnername",value="Ownername"),
       @WebInitParam(name="dbCategory",value="Category"),
       @WebInitParam(name="dbOwnerID",value="Client_ID")
        })
public class SearchServlet extends HttpServlet {
     @Resource (mappedName="jdbc/assignment1")
     private DataSource dataSource;
     private Logger logger;  
     private String sqlcommand1;
     private String sqlcommand2;
     private String input;
     public SearchServlet()
     {
          logger = Logger.getLogger(getClass().getName());
     }
@Override
   public void init()
   {
       ServletConfig config = getServletConfig();
       String table1=config.getInitParameter("dbTable1");
       String table2=config.getInitParameter("dbTable2");
       String clientID=config.getInitParameter("dbOwnerID");
       String petID=config.getInitParameter("dbPetID");
       String firstname=config.getInitParameter("dbfirstname");
       String lastname=config.getInitParameter("dblastname");
       String email=config.getInitParameter("dbEmail");
       String ownername=config.getInitParameter("dbOwnername");
       String petname=config.getInitParameter("dbPetname");
       String petGender=config.getInitParameter("dbPetGender");
       sqlcommand1="SELECT "+lastname+" AS lastname, "+clientID+" AS clientID, "+petID+" AS Pet_ID "+"FROM "+table2+" WHERE "
              + firstname+" = ?  ";
       sqlcommand2="SELECT "+petname+" AS PetName, "+petGender+" AS Pet_Gender, "+clientID+" AS clientID, "+petID+" AS Pet_ID "+"FROM "+table1+" WHERE "
              + ownername+" = ?  ";
       
       
   }
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String userInput=request.getParameter("searchOwner");
        if (userInput == null || userInput.length() == 0)
            userInput = "%";
        
         Connection con = null;
         PreparedStatement psd = null;
         ResultSet rs = null;
         if (sqlcommand2 != null && dataSource != null )
         {
            try {
                con=dataSource.getConnection();
                psd=con.prepareStatement(sqlcommand2);
                psd.setString(1, userInput);
                rs=psd.executeQuery();
                 logger.info("Successfully executed query for owner  "
               + userInput);
              
            } catch (SQLException ex) {
                Logger.getLogger(SearchServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
         }
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Search Owner</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Here is what we find " + filter(userInput) + "</h1>");
            if(rs!=null)
            {
               out.println("<h1>Here is Pet owner's detail</h1>");
               out.println("<TABLE cellspacing=1 border=5>");
               out.println("<TR><TD><B>Client_ID</B></TD>"
                       + "<TD><B>Petname</B>"
                       + "<TD><B>Ownername</B>"
                       + "<TD><B>Pet Gender</B>"
               + "<TD><B>PetID</B></TD></TR>");
                       
             try
            {
               while (rs.next())
               {
                  String ID = rs.getString("clientID");
                //  String ownerFirstname = rs.getString("firstname");
                 // String ownerLastname=rs.getString("lastname");
                  String petname=rs.getString("PetName");
                  String petID=rs.getString("Pet_ID");
                  String petGender=rs.getString("Pet_Gender");
                  out.println("<TR><TD>" + filter(ID) + "</TD>"
                          + "<TD>" + filter(petname)+"</TD>"
                           + "<TD>" + userInput+"</TD>"
                                   + "<TD>" + filter(petGender)+"</TD>"
                     +"<TD>" + filter(petID) + "</TD></TR>");
                   
               }
            
            }
            catch (SQLException e)
            {
               logger.severe("Exception in result set for species "
                  + userInput + ": " + e);
            }
            out.println("</TABLE>");
            }
            out.println("</body>");
            out.println("</html>");
        }
    }
      public static String filter(String text)
   {
      StringBuilder buffer = new StringBuilder();
      for (int i = 0; i < text.length(); i++)
      {
         char c = text.charAt(i);
         if (c == '<')
            buffer.append("&lt;");
         else if (c == '>')
            buffer.append("&gt;");
         else if (c == '\"')
            buffer.append("&quot;");
         else if (c == '\'')
            buffer.append("&#39;");
         else if (c == '&')
            buffer.append("&amp;");
         else
            buffer.append(c);
      }
      return buffer.toString();
   }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>


}
